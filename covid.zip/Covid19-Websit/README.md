# Covid19-Website
This is a static covid-19 helpline website . I have used html ,css, java script, azure Staic Web app  service to create this project . It can tell you the prevention measures , symptoms etc., and also you can book the appointment and concult the doctor in this website.
 
Test my project(my website link): https://icy-smoke-00e0f7010.1.azurestaticapps.net


Homepage image of my website! 

![Screenshot (42)](https://user-images.githubusercontent.com/88210030/170808305-21227b6a-bbfa-460d-8180-856598897319.png)


Some of the images scrrenshots take while creating bot chat(Steps followed)
1. creating the static web app
![Screenshot (40)](https://user-images.githubusercontent.com/88210030/170808322-a53c8cc1-4722-44c8-af30-01ddd5c05700.png)

2. successfully deployed a web page
![Screenshot (41)](https://user-images.githubusercontent.com/88210030/170808335-0176d5bb-1a1a-475e-b907-7c89554c3074.png)
